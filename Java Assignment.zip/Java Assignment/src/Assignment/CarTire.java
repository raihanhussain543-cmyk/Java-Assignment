package Assignment;

public class CarTire extends StockItem {
    private String tireSize;

    public CarTire(int quantity, double price, String stockCode, String tireSize) {
        super(quantity, price, stockCode);
        this.tireSize = tireSize;
    }

    @Override
    public String getStockName() {
        return "Car Tire";
    }

    @Override
    public String getStockDescription() {
        return "Tire size: " + tireSize;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}