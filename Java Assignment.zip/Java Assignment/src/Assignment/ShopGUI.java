package Assignment;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class ShopGUI extends JFrame {
    private ArrayList<StockItem> stockList = new ArrayList<>();
    private JTextArea outputArea;
    private JComboBox<String> typeCombo;
    private JTextField codeField, qtyField, priceField, amountField;

    public ShopGUI() {
        setTitle("Car Parts & Accessories Shop");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Top panel - Create new item
        JPanel createPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        createPanel.setBorder(BorderFactory.createTitledBorder("Create New Stock Item"));

        typeCombo = new JComboBox<>(new String[]{"StockItem (Unknown)", "NavSys", "CarTire", "CarBattery", "EngineOil"});
        codeField = new JTextField("W101");
        qtyField = new JTextField("10");
        priceField = new JTextField("99.99");

        createPanel.add(new JLabel("Item Type:")); createPanel.add(typeCombo);
        createPanel.add(new JLabel("Stock Code:")); createPanel.add(codeField);
        createPanel.add(new JLabel("Initial Quantity:")); createPanel.add(qtyField);
        createPanel.add(new JLabel("Price (no VAT):")); createPanel.add(priceField);

        JButton createBtn = new JButton("Create Item");
        createBtn.addActionListener(e -> createItem());
        createPanel.add(new JLabel("")); createPanel.add(createBtn);

        // Operations panel
        JPanel opPanel = new JPanel(new GridLayout(1, 5, 5, 5));
        opPanel.setBorder(BorderFactory.createTitledBorder("Operations"));

        amountField = new JTextField("5");

        JButton addBtn = new JButton("Add Stock");
        JButton sellBtn = new JButton("Sell Stock");
        JButton priceBtn = new JButton("Change Price");
        JButton showBtn = new JButton("Show Details");
        JButton listBtn = new JButton("List All Stock");

        addBtn.addActionListener(e -> operate("add"));
        sellBtn.addActionListener(e -> operate("sell"));
        priceBtn.addActionListener(e -> operate("price"));
        showBtn.addActionListener(e -> showSelected());
        listBtn.addActionListener(e -> listAllStock());

        opPanel.add(addBtn);
        opPanel.add(sellBtn);
        opPanel.add(priceBtn);
        opPanel.add(showBtn);
        opPanel.add(listBtn);

        // Output area
        outputArea = new JTextArea(15, 60);
        outputArea.setEditable(false);
        JScrollPane scroll = new JScrollPane(outputArea);

        add(createPanel, BorderLayout.NORTH);
        add(opPanel, BorderLayout.CENTER);
        add(scroll, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void createItem() {
        String type = (String) typeCombo.getSelectedItem();
        String code = codeField.getText().trim();
        int qty = Integer.parseInt(qtyField.getText().trim());
        double price = Double.parseDouble(priceField.getText().trim());

        StockItem item = switch (type) {
            case "NavSys" -> new NavSys(qty, price, code);
            case "CarTire" -> new CarTire(qty, price, code, "205/55R16");
            case "CarBattery" -> new CarBattery(qty, price, code, 12);
            case "EngineOil" -> new EngineOil(qty, price, code, "5W-30");
            default -> new StockItem(qty, price, code);
        };

        stockList.add(item);
        outputArea.append("✅ Created: " + item.getStockName() + " (" + code + ")\n\n");
    }

    private void operate(String action) {
        if (stockList.isEmpty()) {
            outputArea.append("No items in stock!\n");
            return;
        }
        StockItem item = stockList.get(stockList.size() - 1);
        String input = amountField.getText().trim();

        try {
            if (action.equals("price")) {
                double newPrice = Double.parseDouble(input);
                item.setPrice(newPrice);
                outputArea.append("Price changed for " + item.getStockName() + "\n");
            } else {
                int amount = Integer.parseInt(input);
                if (action.equals("add")) {
                    item.addStock(amount);
                    outputArea.append("Added stock to " + item.getStockName() + "\n");
                } else if (action.equals("sell")) {
                    boolean success = item.sellStock(amount);
                    outputArea.append("Sell " + (success ? "successful" : "failed") + " for " + item.getStockName() + "\n");
                }
            }
            outputArea.append(item.toString() + "\n\n");
        } catch (NumberFormatException ex) {
            outputArea.append("Invalid number entered!\n");
        }
    }

    private void showSelected() {
        if (!stockList.isEmpty()) {
            outputArea.append(stockList.get(stockList.size() - 1).toString() + "\n\n");
        }
    }

    private void listAllStock() {
        outputArea.append("=== ALL STOCK ===\n");
        for (StockItem item : stockList) {
            outputArea.append(item.toString() + "\n-------------------------\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ShopGUI::new);
    }
}