package Assignment;

public class CarBattery extends StockItem {
    private int voltage;

    public CarBattery(int quantity, double price, String stockCode, int voltage) {
        super(quantity, price, stockCode);
        this.voltage = voltage;
    }

    @Override
    public String getStockName() {
        return "Car Battery";
    }

    @Override
    public String getStockDescription() {
        return "Voltage: " + voltage + "V";
    }

    @Override
    public String toString() {
        return super.toString();
    }
}