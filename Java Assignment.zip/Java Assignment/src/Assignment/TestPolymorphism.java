package Assignment;

import java.util.Scanner;

public class TestPolymorphism {

    public static void itemInstance(StockItem s) {
        try (Scanner scanner = new Scanner(System.in)) {   // this auto-closes the scanner
            System.out.println("\n=== Testing " + s.getStockName() + " ===");

            System.out.print("Enter number of units to add: ");
            int addAmt = scanner.nextInt();
            s.addStock(addAmt);
            System.out.println("After adding stock:");
            System.out.println(s);

            System.out.print("Enter number of units to sell: ");
            int sellAmt = scanner.nextInt();
            boolean sold = s.sellStock(sellAmt);
            System.out.println("Sell successful: " + sold);
            System.out.println("After selling stock:");
            System.out.println(s);

            System.out.print("Enter new price (without VAT): ");
            double newPrice = scanner.nextDouble();
            s.setPrice(newPrice);
            System.out.println("After changing price:");
            System.out.println(s);
        }
    }

    public static void main(String[] args) {
        StockItem[] items = new StockItem[3];
        items[0] = new NavSys(5, 299.99, "NS101");
        items[1] = new CarTire(20, 89.99, "T101", "205/55R16");
        items[2] = new CarBattery(8, 129.99, "B101", 12);

        for (StockItem item : items) {
            itemInstance(item);
        }
    }
}