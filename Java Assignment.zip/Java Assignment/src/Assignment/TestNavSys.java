package Assignment;

public class TestNavSys {
    public static void main(String[] args) {
        NavSys nav = new NavSys(10, 99.99, "NS101");
        
        System.out.println("Task 1. Creating a stock...");
        System.out.println(nav);

        nav.addStock(10);
        System.out.println("\nTask 2. Increasing 10 more units...");
        System.out.println(nav);

        nav.sellStock(2);
        System.out.println("\nTask 3. Sold 2 units...");
        System.out.println(nav);

        nav.setPrice(100.99);
        System.out.println("\nTask 4. Set new price 100.99 per unit...");
        System.out.println(nav);

        nav.addStock(0); // test error message
    }
}