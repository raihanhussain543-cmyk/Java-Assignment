package Assignment;

public class EngineOil extends StockItem {
    private String viscosity;

    public EngineOil(int quantity, double price, String stockCode, String viscosity) {
        super(quantity, price, stockCode);
        this.viscosity = viscosity;
    }

    @Override
    public String getStockName() {
        return "Engine Oil";
    }

    @Override
    public String getStockDescription() {
        return "Viscosity: " + viscosity;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
