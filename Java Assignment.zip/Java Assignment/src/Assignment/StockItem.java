package Assignment;

public class StockItem {
    private String stockCode;
    private int quantityInStock;
    private double price; // without VAT

    public StockItem(int quantity, double price, String stockCode) {
        this.stockCode = stockCode;
        this.price = (price >= 0) ? price : 0.0;
        this.quantityInStock = (quantity >= 0) ? quantity : 0;
    }

    // Getters & Setters
    public String getStockCode() { return stockCode; }
    public int getQuantityInStock() { return quantityInStock; }
    public double getPrice() { return price; } // without VAT

    public void setPrice(double price) {
        if (price >= 0) this.price = price;
    }

    public String getStockName() {
        return "Unknown Stock Name";
    }

    public String getStockDescription() {
        return "Unknown Stock Description";
    }

    public double getVAT() {
        return 17.5;
    }

    public double getPriceWithVAT() {
        return price * (1 + getVAT() / 100.0);
    }

    public void addStock(int amount) {
        if (amount < 1) {
            System.out.println("The error was: Increased item must be greater than or equal to one");
            return;
        }
        if (quantityInStock + amount > 100) {
            System.out.println("The error was: Stock cannot exceed 100 units");
            return;
        }
        quantityInStock += amount;
    }

    public boolean sellStock(int amount) {
        if (amount < 1) {
            System.out.println("The error was: Sold item must be greater than or equal to one");
            return false;
        }
        if (amount <= quantityInStock) {
            quantityInStock -= amount;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Stock Type: " + getStockName() + "\n" +
               "Description: " + getStockDescription() + "\n" +
               "Stock Code: " + getStockCode() + "\n" +
               "Price Without VAT: " + String.format("%.2f", getPrice()) + "\n" +
               "Price With VAT: " + String.format("%.8f", getPriceWithVAT()) + "\n" +
               "Total unit in stock: " + getQuantityInStock();
    }
}